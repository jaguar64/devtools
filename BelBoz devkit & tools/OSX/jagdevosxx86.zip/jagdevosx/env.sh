export SLNPATH=$HOME/jaguar/bin
export PATH=$PATH:$HOME/jaguar/bin
export SMACPATH=$HOME/jaguar/include

