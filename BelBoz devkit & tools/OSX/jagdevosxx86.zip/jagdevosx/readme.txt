Jaguar dev tools version 1.01
October 27th 2009 
OSX x86 Version

The following archive contains a suite of development tools for budding Jaguar
developers who use OS X as their main OS.

First off a big thanks goes out to the following people who made this archive
possible with their various jaguar related dev tools.

Dr. Volker Barthelmann and Frank Wille.  For vbcc, vlink, and vasm
Tursi and Kskunk, for the skunkboard and jcp utility
SubQMod for smac and sln

This archive contains the following

Atari's linux dev tools for the Jaguar and associated files.  The main parts are the sln linker, smac assembler and vbcc for 68000 compiling/linking.

To install do the following.

	untar the archive into your home directory.

	Two sub directories will be created inside your home directory
		jaguar:  Contains the Atari Jaguar tools, and various atari samples

	Also in your home directory you will find two other files.

		vc.config:	This is the configuration for vbcc.  You must
				copy it to the /etc directory.  

		env.sh:		These are the environmental varibales needed
				for proper usage of the dev tools.  You need
				to edit ~/.bash_login and add the contents
				of env.sh to it.

				Be aware that changes to .bash_login to take effect 
				you must close your shell and bring up a new shell

	Once you have extracted the files from the archive in your home directory,
	set the environmental variables as noted above, and copied vc.config
	to /etc, you are ready to develop for the jaguar.

	Check out the demo in /jaguar/examples for a sample of how to use the tools. 
	The jaghello example is a simple program that brings up a blank screen and
	puts some text on it.  This sample uses smac for the assembler, and the
	vbcc compiler/linker. 

	Good luck with the dev tools and if you have any questions feel free to
	drop me an email.

	mhill@hillsoftware.com

