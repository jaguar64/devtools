BJL CDROM for the Jaguar

Version 1.0 (Updated cdrecord 12/30/2005)

----------------------------

This is an encrypted CD that boots the BJL loader giving you the 
ability to download programs into your Jaguar without modifying
your Jaguar.

To use the CD simply burn it (detailed below) and boot it with your
Jaguar.  If you hold the "C" button on Joypad1 while the CD is loading
it will force the code to do 4bit BJL uploads.  If you don't hold the
"C" button you will get the default 8-bit transfer mode.  On large 
program downloads the 8-bit mode is faster, so the only reason I can
think of using 4-bit mode is that the BJL cable would need less wires
so it would be a simpler cable to make.

The BJL code occupies memory from $1F0000 and above.  So you should not 
target code in this memory space.  Once your program is running it can use
this space since your code will not return to the BJL loader.  If you need
to redownload your code you will need to reboot the Jag so it can reload the
BJL loader of the CD.  

------------------------------------------------------------------------------

To burn the CD you will need to go to a command prompt (dos shell)
from Windows.  On Windows XP this is 
     
     START/PROGRAMS/ACCESSORIES/COMMAND PROMPT

On Windows 9X I believe it is 

     START/PROGRAMS/MSDOS PROMPT

You will need to go to wherever you unzipped the BJL CDROM archive to.

	CD \DIRECTORY_YOU_UNZIPPED_THIS_ARCHIVE_Too

Next type the following command at the dosprompt

	cdrecord --scanbus

Be sure to type two minus signs.  If you get an error saying bad command or
that cdrecord is not recognized as a command, you are not in the directory
you unzipped the files to.

Now if it worked you should hopefully get a bunch of text on your screen
listing the various CDROM devices found.  You will want to look through the
list and find your CD burner in the list.

The line in question for my CDRW was the following.

           4,2,0   402) 'TDK     ' 'CDRW121032A     ' '1.00' Removable CD-ROM

The first part of that line is the device number for the CD burner.  In my 
case it is 4,2,0

You need to edit the burn.bat file (don't double click on the burn.bat file or
it will run it, the easiest way to edit the file is to RIGHT click on it and
select edit). When you edit the burn.bat file you need to change BOTH lines that
say

	-dev=4,2,0

Change it to whatever the device number you got for your CD burner when using
the scanbus command.

It is VERY important you change the 4,2,0 on BOTH lines to your device number.

-------------------------------------------------------------------------------

Now obviously from reading the above you are probably aware that you 
will need a BJL cable for your Jaguar!  If you don't have one check
out the following site.  The pinouts are near the bottom.  You can
make one pretty easily.  Make sure to use shielded cable.

	  http://home.t-online.de/home/Matthias.Domin/bjlmod.htm

If you can't build this cable contact me at the email address at the
bottom of the page.  I will build you a cable for $15 plus shipping.
I build 6 foot shielded cables that support 8-bit transfers.

If you need any of the following things, contact me also.  I can 
do BJL modifications (i.e. putting a BJL rom in you Jag), burn 
development ROMS, install development ROMS in Jags, etc. 

If your serious into development on the Jaguar you should probably 
look into doing the BJL hardware mod to your Jaguar since the BJL 
ROM is easier to boot, has the monitor screen that shows you registers
and other useful information.  

An even better option is to find an Alpine board for your Jaguar. They 
are hard to come by and pretty expensive ($300+), but nothing beats
them if your serious into development on the Jag.

You can find information on the cdrecord program included here at the following
site.

	http://cdrecord.berlios.de/test/index.php

They have documentation, possibly newer versions, and source code to cdrecord.  
If your having trouble with cdrecord check out the above site.

Michael Hill
mhill@hillsoftware.com
