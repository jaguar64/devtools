foo()
{
	short local=0,test;

	local +=321;
	test = (local-1)/11;
	return (test);
}
