/******************************************************************************
raw8tohdr.c 

Copyright (C) 2005 Michael Hill

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
******************************************************************************/

/******************************************************************************
 Program to convert Photoshop Elements (and probably Photoshop) saved 8bit
 pallette files to a compilable header file.
 
 I use Elements to create my image file.  I then save it to a Photoshop RAW
 format.  I then go and saved the 256 color pallette to disk also.
 
 Then run this program and pass the pallette file as the first argument
 and the header filename you want created as the second argument.  Upon
 finishing the header file is compilable into your code and can be dumped into
 the CLUT on the Jag.
 
 The code could be easily edited to allow generation of a binary file that 
 contains the raw CLUT data also.   You could include it and the raw 8 bit 
 image file into your assembly code directly.
******************************************************************************/

#include<stdio.h>

FILE *in,*out;

int main(int argc,char *argv[]) 
{
  unsigned char r,g,b;
  int x;
  unsigned short int rgb;


  if(argc < 3) 
  {
    puts("format is raw8tohdr srcfile.pal dstfile.h");
    return 0;
  }
  
  in=fopen(argv[1],"rb");
  if(in==NULL) 
  {
    puts("File Not Found");
    return 0;
  }
  out=fopen(argv[2],"wb");

  fprintf(out,"unsigned short int pallete[]={\n");
  for(x=0;x<256;x++) 
  {
    r=fgetc(in);
    g=fgetc(in);
    b=fgetc(in);

    r=r>>3;
    g=g>>2;
    b=b>>3;

    rgb = r << 11;
    rgb = rgb + (b << 6);
    rgb += g;
                
    if(x!=255) fprintf(out,"0x%04x, ",rgb);
    else fprintf(out,"0x%04x",rgb); 
    
    if((x+1) % 8 == 0) fprintf(out,"\n");

  }
  fprintf(out,"};\n");
  fclose(out);
  fclose(in);
}
